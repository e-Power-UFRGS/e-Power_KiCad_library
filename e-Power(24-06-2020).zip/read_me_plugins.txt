Como adicionar os plugins ao KiCad?

1 - Copiar todas as pastas que estão dentro da pasta "Kicad_action_plugins-master"

2 - Colar algo semelhante a: 
"C:\Program Files\KiCad\share\kicad\scripting\plugins"
(varia dependendo de onde KiCad foi instalado no computador)

3 - No kicad, abrir "PCB Layout Editor"

4 - Clicar em: Preferences > Preferences

5 - Dentro de "Pcbnew" clicar em "Action Plugins"

6 - Marcar o "Replicate layout" e dar "OK"

Links que podem ajudar:
https://github.com/MitjaNemec/Kicad_action_plugins
https://www.youtube.com/watch?v=hJXADScAhN0&t=359s